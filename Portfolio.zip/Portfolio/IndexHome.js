// Dropdown menu (only visibly on hover)
document.getElementById('name').addEventListener('mouseover', function() {
    document.getElementById('dropdown').style.display = 'block';
});

document.getElementById('name').addEventListener('mouseout', function() {
    document.getElementById('dropdown').style.display = 'none';
});

document.getElementById('dropdown').addEventListener('mouseover', function() {
    document.getElementById('dropdown').style.display = 'block';
});

document.getElementById('dropdown').addEventListener('mouseout', function() {
    document.getElementById('dropdown').style.display = 'none';
});

// Fonts to cycle through
const fonts = ['Arial', 'Courier New', 'Georgia', 'Times New Roman', 'Verdana', 'Impact', 'Lucida Console', 'Tahoma', 'Trebuchet MS', 'Cabinet Grotesk', 'Zodiak', 'RX100', 'Supereme'];

// Function to cycle fonts for each letter
function cycleFonts(element) {
    const letters = element.textContent.split('');
    element.innerHTML = letters.map(letter => `<span>${letter}</span>`).join('');

    const spans = element.querySelectorAll('span');
    spans.forEach(span => {
        setInterval(() => {
            const randomFont = fonts[Math.floor(Math.random() * fonts.length)];
            span.style.fontFamily = randomFont;
        }, Math.random() * 1000 + 500); // Random interval between 500ms and 1500ms
    });
}

// Apply the font cycling to the name
cycleFonts(document.getElementById('name'));