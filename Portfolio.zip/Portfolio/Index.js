// Dropdown menu (only visibly on hover)
document.getElementById('name2').addEventListener('mouseover', function() {
    document.getElementById('dropdown2').style.display = 'block';
});

document.getElementById('name2').addEventListener('mouseout', function() {
    document.getElementById('dropdown2').style.display = 'none';
});

document.getElementById('dropdown2').addEventListener('mouseover', function() {
    document.getElementById('dropdown2').style.display = 'block';
});

document.getElementById('dropdown2').addEventListener('mouseout', function() {
    document.getElementById('dropdown2').style.display = 'none';
});

// Fonts to cycle through
const fonts = ['Arial', 'Courier New', 'Georgia', 'Times New Roman', 'Verdana', 'Impact', 'Lucida Console', 'Tahoma', 'Trebuchet MS', 'Cabinet Grotesk', 'Zodiak', 'RX100', 'Supereme'];

// Function to cycle fonts for each letter once, so text on pages isn't jittery
function cycleFontsOnce(element) {
    const letters = element.textContent.split('');
    const fontSpans = letters.map(letter => {
      const randomFont = fonts[Math.floor(Math.random() * fonts.length)];
      return `<span style="font-family: ${randomFont}">${letter}</span>`;
    });
  
    element.innerHTML = fontSpans.join('');
  }

//Apply font cycle once
cycleFontsOnce(document.getElementById('name2'));